#pragma once
#include "geometry.hpp"

namespace fire_scout {

// A geometric speed cap is not evidence of a blocked flight controller.  Give
// the planner a bounded opportunity to repair it while retaining independent
// command-response and zero-motion checks.  This policy never raises a speed.
struct ProfileProgressConfig {
  double speed_threshold{.12}, repair_delay{2.0}, repair_repeat{2.0};
  double recovery_grace{8.0};
  bool valid() const {
    return std::isfinite(speed_threshold) && speed_threshold>0 && speed_threshold<=.30 &&
      std::isfinite(repair_delay) && repair_delay>0 &&
      std::isfinite(repair_repeat) && repair_repeat>0 &&
      std::isfinite(recovery_grace) && recovery_grace>=repair_delay+repair_repeat;
  }
};

struct ProfileProgressDecision {
  bool limited{false}, request_repair{false}, request_recovery{false};
  const char *reason{"NORMAL_PROGRESS"};
};

class ProfileProgressMonitor {
public:
  ProfileProgressConfig cfg;
  void reset() {
    active_=false;elapsed_=window_time_=expected_=displacement_=0;
    next_report_=cfg.repair_delay;
  }
  ProfileProgressDecision update(bool limited,Vec3 position,Vec3 sent_velocity,double dt) {
    if(!limited || !finite(position) || !finite(sent_velocity) ||
       !std::isfinite(dt) || dt<0) {reset();return {};}
    ProfileProgressDecision result;result.limited=true;result.reason="PROFILE_LIMITED";
    if(!active_) {
      active_=true;anchor_=position;next_report_=cfg.repair_delay;
      return result;
    }
    elapsed_+=dt;window_time_+=dt;expected_+=norm(sent_velocity)*dt;
    displacement_=distance(position,anchor_);
    if(elapsed_+1e-9>=next_report_) {
      result.request_repair=true;next_report_=elapsed_+cfg.repair_repeat;
    }
    if(window_time_+1e-9>=cfg.recovery_grace) {
      // A .04 m/s crawl normally makes .32 m in this window: it requests a
      // profile repair, not a retreat. A frozen vehicle under that same command
      // must still recover. Net displacement also exposes repeated oscillation.
      const bool no_response=expected_>=.10 &&
        displacement_<std::max(.04,.25*expected_);
      const bool no_command=expected_<.10 && displacement_<.03;
      if(no_response || no_command) {
        result.request_recovery=true;
        result.reason=no_response?"PROFILE_COMMAND_NOT_FOLLOWED":"PROFILE_REPAIR_TIMEOUT";
      }else {
        anchor_=position;window_time_=expected_=0;
      }
    }
    return result;
  }
  double seconds() const {return elapsed_;}
  double expectedDistance() const {return expected_;}
  double displacement() const {return displacement_;}
private:
  bool active_{false};Vec3 anchor_{};
  double elapsed_{0},window_time_{0},expected_{0},displacement_{0},next_report_{2};
};

}  // namespace fire_scout
